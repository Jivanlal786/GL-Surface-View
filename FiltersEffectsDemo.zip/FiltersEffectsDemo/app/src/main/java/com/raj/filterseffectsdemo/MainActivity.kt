package com.raj.filterseffectsdemo

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.media.effect.Effect
import android.media.effect.EffectContext
import android.media.effect.EffectFactory
import android.opengl.GLES20
import android.opengl.GLException
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.RelativeLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.nio.IntBuffer
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLContext
import javax.microedition.khronos.opengles.GL10


class MainActivity : AppCompatActivity(), GLSurfaceView.Renderer {

    companion object {
        var screenshot: Bitmap? = null
        var snapshotBitmap: Bitmap? = null
    }

    private val TAG: String = "JJJJJJJJJ"
    private val STATE_CURRENT_EFFECT = "current_effect"

    var mEffectView: GLSurfaceView? = null
    private val mTextures = IntArray(2)
    private var mEffectContext: EffectContext? = null
    private var mEffect: Effect? = null
    private val mTexRenderer: TextureRenderer = TextureRenderer()
    private var mImageWidth = 0
    private var mImageHeight = 0
    private var mInitialized = false
    private var mCurrentEffect = "0"

    var brightness_value = 1f
    var contrast_value = 1f
    var fill_light_value = 1f
    var grain_value = 1f
    var saturation_value = 1f
    var sharpen_value = 1f
    var temperature_value = 1f
    var vignette_value = 1f

    var none: TextView? = null
    var autofix: TextView? = null
    var bw: TextView? = null
    var brightness: TextView? = null
    var contrast: TextView? = null
    var crossprocess: TextView? = null
    var documentary: TextView? = null
    var duotone: TextView? = null
    var filllight: TextView? = null
    var fisheye: TextView? = null
    var flipvert: TextView? = null
    var fliphor: TextView? = null
    var grain: TextView? = null
    var grayscale: TextView? = null
    var lomoish: TextView? = null
    var negative: TextView? = null
    var posterize: TextView? = null
    var rotate: TextView? = null
    var saturation: TextView? = null
    var sepia: TextView? = null
    var sharpen: TextView? = null
    var temperature: TextView? = null
    var tint: TextView? = null
    var vignette: TextView? = null

    var brightness_seekbar: SeekBar? = null
    var contrast_seekbar: SeekBar? = null
    var fill_light_seekbar: SeekBar? = null
    var grain_seekbar: SeekBar? = null
    var saturation_seekbar: SeekBar? = null
    var sharpen_seekbar: SeekBar? = null
    var temperature_seekbar: SeekBar? = null
    var vignette_seekbar: SeekBar? = null
    var tvSave: TextView? = null
    var rlImage: RelativeLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mEffectView = findViewById(R.id.effectsview)


        none = findViewById(R.id.none_text)
        autofix = findViewById(R.id.autofix_text)
        bw = findViewById(R.id.colorintensity_text)
        brightness = findViewById(R.id.brightness_text)
        contrast = findViewById(R.id.contrast_text)
        crossprocess = findViewById(R.id.crossprocess_text)
        documentary = findViewById(R.id.documentary_text)
        duotone = findViewById(R.id.duotone_text)
        filllight = findViewById(R.id.filllight_text)
        fisheye = findViewById(R.id.fisheye_text)
        flipvert = findViewById(R.id.flipvert_text)
        fliphor = findViewById(R.id.fliphor_text)
        grain = findViewById(R.id.grain_text)
        grayscale = findViewById(R.id.grayscale_text)
        lomoish = findViewById(R.id.lomoish_text)
        negative = findViewById(R.id.negative_text)
        posterize = findViewById(R.id.posterize_text)
        rotate = findViewById(R.id.rotate_text)
        saturation = findViewById(R.id.saturate_text)
        sepia = findViewById(R.id.sepia_text)
        sharpen = findViewById(R.id.sharpen_text)
        temperature = findViewById(R.id.temperature_text)
        tint = findViewById(R.id.tint_text)
        vignette = findViewById(R.id.vignette_text)

        brightness_seekbar = findViewById(R.id.brightness_seekbar)
        contrast_seekbar = findViewById(R.id.contrast_seekbar)
        fill_light_seekbar = findViewById(R.id.fill_light_seekbar)
        grain_seekbar = findViewById(R.id.grain_seekbar)
        saturation_seekbar = findViewById(R.id.saturation_seekbar)
        sharpen_seekbar = findViewById(R.id.sharpen_seekbar)
        temperature_seekbar = findViewById(R.id.temperature_seekbar)
        vignette_seekbar = findViewById(R.id.vignette_seekbar)
        vignette_seekbar = findViewById(R.id.vignette_seekbar)
        tvSave = findViewById(R.id.tv_save)
        rlImage = findViewById(R.id.rl_image)

        mEffectView!!.setEGLContextClientVersion(2)
        mEffectView!!.setRenderer(this)
        mEffectView!!.setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY)
        if (null != savedInstanceState && savedInstanceState.containsKey(STATE_CURRENT_EFFECT)) {
            setCurrentEffect(savedInstanceState.getString(STATE_CURRENT_EFFECT)!!)
        } else {
            setCurrentEffect("none")
        }

        brightness_seekbar!!.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                mEffectView!!.requestRender()
                mCurrentEffect = "brightness"
                brightness_value = p0!!.progress.toFloat() / 10
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {}
            override fun onStopTrackingTouch(p0: SeekBar?) {}
        })

        contrast_seekbar!!.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                mEffectView!!.requestRender()
                mCurrentEffect = "contrast"
                contrast_value = p0!!.progress.toFloat() / 10
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {}
            override fun onStopTrackingTouch(p0: SeekBar?) {}
        })

        fill_light_seekbar!!.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                mEffectView!!.requestRender()
                mCurrentEffect = "filllight"
                fill_light_value = p0!!.progress.toFloat() / 100
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {}
            override fun onStopTrackingTouch(p0: SeekBar?) {}
        })

        grain_seekbar!!.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                mEffectView!!.requestRender()
                mCurrentEffect = "grain"
                grain_value = p0!!.progress.toFloat() / 100
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {}
            override fun onStopTrackingTouch(p0: SeekBar?) {}
        })

        saturation_seekbar!!.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                mEffectView!!.requestRender()
                mCurrentEffect = "saturate"
                saturation_value = p0!!.progress.toFloat() / 100
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {}
            override fun onStopTrackingTouch(p0: SeekBar?) {}
        })

        sharpen_seekbar!!.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                mEffectView!!.requestRender()
                mCurrentEffect = "sharpen"
                sharpen_value = p0!!.progress.toFloat() / 10
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {}
            override fun onStopTrackingTouch(p0: SeekBar?) {}
        })

        temperature_seekbar!!.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                mEffectView!!.requestRender()
                mCurrentEffect = "temperature"
                temperature_value = p0!!.progress.toFloat() / 100
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {}
            override fun onStopTrackingTouch(p0: SeekBar?) {}
        })

        vignette_seekbar!!.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                mEffectView!!.requestRender()
                mCurrentEffect = "vignette"
                vignette_value = p0!!.progress.toFloat() / 20
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {}
            override fun onStopTrackingTouch(p0: SeekBar?) {}
        })

        tvSave!!.setOnClickListener(View.OnClickListener {
//            rlImage!!.setDrawingCacheEnabled(true);
//            screenshot = Bitmap.createBitmap(rlImage!!.getDrawingCache());
//            rlImage!!.setDrawingCacheEnabled(false);
//            Log.v(TAG, "Screenshot height: " + screenshot!!.getHeight());
//            image.setImageBitmap(screenshot);

            captureBitmap(object : BitmapReadyCallbacks {
                override fun onBitmapReady(bitmap: Bitmap?) {
                    screenshot = bitmap
                    var intent = Intent(this@MainActivity,DemoActivity::class.java)
                    startActivity(intent)
                }
            })

        })

        none!!.setOnClickListener {
            mEffectView!!.requestRender()
            mCurrentEffect = "none"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE
        }
        autofix!!.setOnClickListener {
            mEffectView!!.requestRender()
            mCurrentEffect = "autofix"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE
        }
        bw!!.setOnClickListener {
            mEffectView!!.requestRender()
            mCurrentEffect = "bw"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE
        }
        brightness!!.setOnClickListener {
//            mEffectView!!.requestRender()
//            mCurrentEffect = "brightness"

            brightness_seekbar!!.visibility = View.VISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE

            brightness_seekbar!!.progress = 10
        }
        contrast!!.setOnClickListener {
//            mEffectView!!.requestRender()
//            mCurrentEffect = "contrast"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.VISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE

            contrast_seekbar!!.progress = 10
        }
        crossprocess!!.setOnClickListener {
            mEffectView!!.requestRender()
            mCurrentEffect = "crossprocess"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE
        }
        documentary!!.setOnClickListener {
            mEffectView!!.requestRender()
            mCurrentEffect = "documentary"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE
        }
        duotone!!.setOnClickListener {
            mEffectView!!.requestRender()
            mCurrentEffect = "duotone"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE
        }
        filllight!!.setOnClickListener {
//            mEffectView!!.requestRender()
//            mCurrentEffect = "filllight"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.VISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE

            fill_light_seekbar!!.progress = 0
        }
        fisheye!!.setOnClickListener {
            mEffectView!!.requestRender()
            mCurrentEffect = "fisheye"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE
        }
        flipvert!!.setOnClickListener {
            mEffectView!!.requestRender()
            mCurrentEffect = "flipvert"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE
        }
        fliphor!!.setOnClickListener {
            mEffectView!!.requestRender()
            mCurrentEffect = "fliphor"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE
        }
        grain!!.setOnClickListener {
//            mEffectView!!.requestRender()
//            mCurrentEffect = "grain"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.VISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE

            grain_seekbar!!.progress = 0
        }
        grayscale!!.setOnClickListener {
            mEffectView!!.requestRender()
            mCurrentEffect = "grayscale"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE
        }
        lomoish!!.setOnClickListener {
            mEffectView!!.requestRender()
            mCurrentEffect = "lomoish"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE
        }
        negative!!.setOnClickListener {
            mEffectView!!.requestRender()
            mCurrentEffect = "negative"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE
        }
        posterize!!.setOnClickListener {
            mEffectView!!.requestRender()
            mCurrentEffect = "posterize"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE
        }
        rotate!!.setOnClickListener {
            mEffectView!!.requestRender()
            mCurrentEffect = "rotate"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE
        }
        saturation!!.setOnClickListener {
//            mEffectView!!.requestRender()
//            mCurrentEffect = "saturate"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.VISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE

            saturation_seekbar!!.progress = 0
        }
        sepia!!.setOnClickListener {
            mEffectView!!.requestRender()
            mCurrentEffect = "sepia"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE
        }
        sharpen!!.setOnClickListener {
//            mEffectView!!.requestRender()
//            mCurrentEffect = "sharpen"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.VISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE

            sharpen_seekbar!!.progress = 0
        }
        temperature!!.setOnClickListener {
//            mEffectView!!.requestRender()
//            mCurrentEffect = "temperature"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.VISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE

            temperature_seekbar!!.progress = 50
        }
        tint!!.setOnClickListener {
            mEffectView!!.requestRender()
            mCurrentEffect = "tint"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.INVISIBLE
        }
        vignette!!.setOnClickListener {
//            mEffectView!!.requestRender()
//            mCurrentEffect = "vignette"

            brightness_seekbar!!.visibility = View.INVISIBLE
            contrast_seekbar!!.visibility = View.INVISIBLE
            fill_light_seekbar!!.visibility = View.INVISIBLE
            grain_seekbar!!.visibility = View.INVISIBLE
            saturation_seekbar!!.visibility = View.INVISIBLE
            sharpen_seekbar!!.visibility = View.INVISIBLE
            temperature_seekbar!!.visibility = View.INVISIBLE
            vignette_seekbar!!.visibility = View.VISIBLE

            vignette_seekbar!!.progress = 1
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.media_effects, menu)
        return true
    }

//    fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater) {
//        inflater.inflate(R.menu.media_effects, menu)
//    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        setCurrentEffect(item.itemId)
        mEffectView!!.requestRender()
        return true
    }

    override fun onSaveInstanceState(outState: Bundle, outPersistentState: PersistableBundle) {
        outState.putString(STATE_CURRENT_EFFECT, mCurrentEffect)
    }

    override fun onSurfaceCreated(p0: GL10?, p1: EGLConfig?) {

    }

    override fun onSurfaceChanged(p0: GL10?, width: Int, height: Int) {
        if (mTexRenderer != null) {
            mTexRenderer.updateViewSize(width, height)
        }
    }



    private interface BitmapReadyCallbacks {
        fun onBitmapReady(bitmap: Bitmap?)
    }

    private fun captureBitmap(bitmapReadyCallbacks: BitmapReadyCallbacks) {
        mEffectView!!.queueEvent {
            val egl = EGLContext.getEGL() as EGL10
            val gl = egl.eglGetCurrentContext().gl as GL10
            snapshotBitmap =
                createBitmapFromGLSurface(0, 0, mEffectView!!.width, mEffectView!!.height, gl)
            runOnUiThread { bitmapReadyCallbacks.onBitmapReady(snapshotBitmap) }
        }
    }

    // from other answer in this question
    private fun createBitmapFromGLSurface(x: Int, y: Int, w: Int, h: Int, gl: GL10): Bitmap? {
        val bitmapBuffer = IntArray(w * h)
        val bitmapSource = IntArray(w * h)
        val intBuffer: IntBuffer = IntBuffer.wrap(bitmapBuffer)
        intBuffer.position(0)
        try {
            gl.glReadPixels(x, y, w, h, GL10.GL_RGBA, GL10.GL_UNSIGNED_BYTE, intBuffer)
            var offset1: Int
            var offset2: Int
            for (i in 0 until h) {
                offset1 = i * w
                offset2 = (h - i - 1) * w
                for (j in 0 until w) {
                    val texturePixel = bitmapBuffer[offset1 + j]
                    val blue = texturePixel shr 16 and 0xff
                    val red = texturePixel shl 16 and 0x00ff0000
                    val pixel = texturePixel and -0xff0100 or red or blue
                    bitmapSource[offset2 + j] = pixel
                }
            }
        } catch (e: GLException) {
            Log.e(TAG, "createBitmapFromGLSurface: " + e.message, e)
            return null
        }
        return Bitmap.createBitmap(bitmapSource, w, h, Bitmap.Config.ARGB_8888)
    }

    override fun onDrawFrame(p0: GL10?) {
        if (!mInitialized) {
            //Only need to do this once
            mEffectContext = EffectContext.createWithCurrentGlContext()
            mTexRenderer.init()
            loadTextures()
            mInitialized = true
        }
        if (mCurrentEffect != "none") {
            //if an effect is chosen initialize it and apply it to the texture
            initEffect()
            applyEffect()
        }
        renderResult()


    }

    private fun setCurrentEffect(effect: String) {
        mCurrentEffect = effect
    }

    private fun loadTextures() {
        // Generate textures
        GLES20.glGenTextures(2, mTextures, 0)

        // Load input bitmap
        val bitmap = BitmapFactory.decodeResource(resources, R.drawable.aaa)
        mImageWidth = bitmap.width
        mImageHeight = bitmap.height
        mTexRenderer.updateTextureSize(mImageWidth, mImageHeight)

        // Upload to texture
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mTextures[0])
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)

        // Set texture parameters
        GLToolbox.initTexParams()
    }

    private fun initEffect() {
        val effectFactory = mEffectContext!!.factory
        if (mEffect != null) {
            mEffect!!.release()
        }
        when (mCurrentEffect) {
            "none" -> {}
            "autofix" -> {
                mEffect = effectFactory.createEffect(EffectFactory.EFFECT_AUTOFIX)
                mEffect!!.setParameter("scale", 0.5f)
            }
            "bw" -> {
                mEffect = effectFactory.createEffect(EffectFactory.EFFECT_BLACKWHITE)
                mEffect!!.setParameter("black", .1f)
                mEffect!!.setParameter("white", .7f)
            }
            "brightness" -> {
                mEffect = effectFactory.createEffect(EffectFactory.EFFECT_BRIGHTNESS)
//                mEffect!!.setParameter("brightness", 2.0f)
                mEffect!!.setParameter("brightness", brightness_value)
            }
            "contrast" -> {
                mEffect = effectFactory.createEffect(EffectFactory.EFFECT_CONTRAST)
//                mEffect!!.setParameter("contrast", 1.4f)
                mEffect!!.setParameter("contrast", contrast_value)
            }
            "crossprocess" -> {
                mEffect = effectFactory.createEffect(EffectFactory.EFFECT_CROSSPROCESS)
            }
            "documentary" -> {
                mEffect = effectFactory.createEffect(EffectFactory.EFFECT_DOCUMENTARY)
            }
            "duotone" -> {
                mEffect = effectFactory.createEffect(EffectFactory.EFFECT_DUOTONE)
                mEffect!!.setParameter("first_color", Color.YELLOW)
                mEffect!!.setParameter("second_color", Color.DKGRAY)
            }
            "filllight" -> {
                mEffect = effectFactory.createEffect(EffectFactory.EFFECT_FILLLIGHT)
//                mEffect!!.setParameter("strength", .8f)
                mEffect!!.setParameter("strength", fill_light_value)
            }
            "fisheye" -> {
                mEffect = effectFactory.createEffect(EffectFactory.EFFECT_FISHEYE)
                mEffect!!.setParameter("scale", .5f)
            }
            "flipvert" -> {
                mEffect = effectFactory.createEffect(EffectFactory.EFFECT_FLIP)
                mEffect!!.setParameter("vertical", true)
            }
            "fliphor" -> {
                mEffect = effectFactory.createEffect(EffectFactory.EFFECT_FLIP)
                mEffect!!.setParameter("horizontal", true)
            }
            "grain" -> {
                mEffect = effectFactory.createEffect(EffectFactory.EFFECT_GRAIN)
//                mEffect!!.setParameter("strength", 1.0f)
                mEffect!!.setParameter("strength", grain_value)
            }
            "grayscale" -> mEffect = effectFactory.createEffect(EffectFactory.EFFECT_GRAYSCALE)
            "lomoish" -> mEffect = effectFactory.createEffect(EffectFactory.EFFECT_LOMOISH)
            "negative" -> mEffect = effectFactory.createEffect(EffectFactory.EFFECT_NEGATIVE)
            "posterize" -> mEffect = effectFactory.createEffect(EffectFactory.EFFECT_POSTERIZE)
            "rotate" -> {
                mEffect = effectFactory.createEffect(EffectFactory.EFFECT_ROTATE)
                mEffect!!.setParameter("angle", 180)
            }
            "saturate" -> {
                mEffect = effectFactory.createEffect(EffectFactory.EFFECT_SATURATE)
//                mEffect!!.setParameter("scale", .5f)
                mEffect!!.setParameter("scale", saturation_value)
            }
            "sepia" -> mEffect = effectFactory.createEffect(EffectFactory.EFFECT_SEPIA)
            "sharpen" -> {
                mEffect = effectFactory.createEffect(EffectFactory.EFFECT_SHARPEN)
                mEffect!!.setParameter("scale", sharpen_value)
            }
            "temperature" -> {
                mEffect = effectFactory.createEffect(EffectFactory.EFFECT_TEMPERATURE)
//                mEffect!!.setParameter("scale", .9f)
                mEffect!!.setParameter("scale", temperature_value)
            }
            "tint" -> {
                mEffect = effectFactory.createEffect(EffectFactory.EFFECT_TINT)
                mEffect!!.setParameter("tint", Color.MAGENTA)
            }
            "vignette" -> {
                mEffect = effectFactory.createEffect(EffectFactory.EFFECT_VIGNETTE)
//                mEffect!!.setParameter("scale", .5f)
                mEffect!!.setParameter("scale", vignette_value)
            }
            else -> {}
        }
    }

    private fun applyEffect() {
        mEffect!!.apply(mTextures[0], mImageWidth, mImageHeight, mTextures[1])
    }

    private fun renderResult() {
        if (mCurrentEffect == "none") {
            // if no effect is chosen, just render the original bitmap
            mTexRenderer.renderTexture(mTextures[0])
        } else {
            // render the result of applyEffect()
            mTexRenderer.renderTexture(mTextures[1])
        }
    }
}