package com.raj.filterseffectsdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

public class DemoActivity extends AppCompatActivity {

    ImageView ivImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo);

        ivImage = findViewById(R.id.iv_screenshot);


        try {
            ivImage.setImageBitmap(MainActivity.Companion.getScreenshot());
        }catch (Exception e){
            e.printStackTrace();
            Log.e("JJJJJJJJJJJ", "onCreate: bitmap is nul == "+e.getMessage());
        }
    }
}